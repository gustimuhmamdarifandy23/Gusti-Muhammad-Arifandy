package com.uty.listview;

import android.app.Activity;

public class MainActivity extends Activity {
}
