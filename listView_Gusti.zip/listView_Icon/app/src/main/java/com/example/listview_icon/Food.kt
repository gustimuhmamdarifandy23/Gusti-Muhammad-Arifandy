package com.example.listview_icon

class Food {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}